# -*- coding: utf-8 -*-
"""Copy of S6-SS_comp.ipynb

author: anupkhalder
"""

import sys,os,time
import json,csv,numpy as np,math
from pathlib import Path
from joblib import dump, load

"""## S1: Load Protein-GO-Annotation  mapping:
 [Protein: -> GO sub-graph type (CC, MF, BP) :-> IEA or nonIEA (+, -)]
"""

def LoadIEA_annot(path):
  with open(f'{path}/Annotations/Annotation_ProGOIEAt.json','r') as f :    
      gowIEA=json.load(f)
  return gowIEA

"""### S2: Load ICA """

def LoadICA(path,Torg):
  with open(f'{path}/ICA_DATA/HS-{Torg}_GO_ICA.json','r') as f :
      ica = json.load(f)
  # print(len(ica))
  return ica



"""## S3: Load target protein pair : Human - SARS, Human - SARS-CoV2, Human - MERS..."""

def loadINTR(path,Torg):
  with open(f'{path}/INTERACTION/HS-{Torg}-ProtPair.json','r') as f :
      hs_intrA=json.load(f)
  return hs_intrA

"""## S4: Load Cluster Center and path length to Root"""

def loadPathL(path,key):
    with open(f'{path}/ROOT_files/{key}_roots.json','r') as f :
        roots = json.load(f)
    with open(f'{path}/toROOT_PATH_length/{key}_toroot_pathlenght.json','r') as f :
        path_len = json.load(f)
    return roots,path_len

"""## S5: Load Graph Data"""

def loadGraphData(path):

  with open(f"{path}/GO_GRAPH/GOgraphAnc.json","r") as f :
      GOgraph = json.load(f)
  with open(f"{path}/GO_GRAPH/GO_all_ancestors.json','r') as f :
      goAnc = json.load(f)
  with open(f"{path}/GO_GRAPH/GO_all_descendants.json','r') as f :
      goDsc = json.load(f)
  return GOgraph,goAnc,goDsc

"""## S6: SS computation details."""

def membership_function(k,path_len) :
    #global path_len
    memfn = {}
    b = 2*k*k
    for i in path_len :
        memfn[i] = {}
        for j in path_len[i] :
            a = math.pow(path_len[i][j],2)
            x = float(a)/b
            mfn = math.exp(-x)
            memfn[i][j] = float("{0:.2f}".format(mfn))
    return memfn

def dfs_paths(start, goal, ipath=None):
    if ipath is None:
        ipath = [start]
    if start == goal:
        yield ipath
    for nxt in set(GOgraph[start]) - set(ipath):
        yield from dfs_paths(nxt, goal, ipath + [nxt])

def Share(c1,c2,membrfn,roots) :
    global goAnc,goDsc,ica
    anc1 = goAnc[c1]
    anc2 = goAnc[c2]
    commonAnc = list(set(anc1) & set(anc2))
    #print(c1,c2,"::",commonAnc)
    cmnAnc = {}
    for i in commonAnc :
        cmnAnc[i] = ica[i]
    commonAnc = sorted(commonAnc, key=cmnAnc.__getitem__,reverse=True)
    PD = {}
    for a in commonAnc :
        PD[a] = abs(len(list(dfs_paths(c1,a))) - len(list(dfs_paths(c2,a))))
    PD_val = {}
    for k, v in PD.items():
        PD_val.setdefault(v, []).append(k)
    CommonDisjAnc = []
    for b in PD_val :
        if len(PD_val[b]) == 1 :
            CommonDisjAnc.append(PD_val[b][0])
        if len(PD_val[b]) > 1 :
            index_list = []
            for g in PD_val[b] :
                index_list.append(commonAnc.index(g))
            index_list.sort()
            CommonDisjAnc.append(commonAnc[index_list[0]])
    mx1 = 0
    vc = 0
    if c1 in membrfn and c2 in membrfn:
        for i in roots :
            valid = 0
            if all(x in goAnc[i] for x in [c1,c2]) :
                valid += 1
            if all(x in goDsc[i] for x in [c1,c2]) :
                valid += 1
            if valid != 0 :
                diff = abs(membrfn[c1][i] - membrfn[c2][i])
            else :
                diff = 0
                vc += 1
            if diff > mx1 :
                mx1 = diff
    if mx1 == 0 and vc == len(roots) :
        if c1 in membrfn and c2 in membrfn:
            for i in roots :
                #print("::",i,c1,c2)
                if i in membrfn[c1] and i in membrfn[c2]:
                    diff = abs(membrfn[c1][i] - membrfn[c2][i])
                    if diff > mx1 :
                        mx1 = diff
    wt = 1 - mx1
    shared = 0
    rel = 0
    disjlen = len(CommonDisjAnc)
    if disjlen != 0 :
        for cda in CommonDisjAnc :
            shared += ica[cda]
        rel = (wt*shared)/disjlen

    return rel

def SS(path,org,key,hs_intr,ieaT,roots,path_len,ica,gowIEA):
    
    start_time=time.time()
    k=3
    
    fuzzy_sim1 = []
    membrfn = membership_function(k,path_len)
    cnt = 0
    fuzzySc={}
    for i in hs_intr :
        cnt = cnt+1
        pair_list = []
        go1 = gowIEA[i[0]][key][ieaT]
        go2 = gowIEA[i[1]][key][ieaT]
        l1 = len(go1);l2 = len(go2)
        ln = l1+l2
        if l1 != 0 and l2 != 0 :
            for j in go1 :
                if j in ica :
                    for l in go2 :
                        if l in ica :
                            if [j,l] not in pair_list :
                                pair_list.append([j,l])
            for j in go2 :
                if j in ica :
                    for l in go1 :
                        if l in ica :
                            p = [j,l]
                            if not any(x in pair_list for x in [p,p[::-1]]) :
                                pair_list.append(p)
            simVal = []
            for ai in pair_list :
                sem = Share(ai[0],ai[1],membrfn,roots)
                simVal.append(sem)

            sum1 = 0
            for j in go1 :
                if j in ica :
                    mx = 0
                    for l in go2 :
                        if l in ica :
                            g = [j,l]
                            if g in pair_list :
                                simV = simVal[pair_list.index(g)]
                            else :
                                simV = simVal[pair_list.index(g[::-1])]
                            if simV > mx :
                                mx = simV
                    sum1 = sum1 + mx

            sum2 = 0
            for j in go2 :
                if j in ica :
                    mx = 0
                    for l in go1 :
                        if l in ica :
                            g = [j,l]
                            if g in pair_list :
                                simV = simVal[pair_list.index(g)]
                            else :
                                simV = simVal[pair_list.index(g[::-1])]
                            if simV > mx :
                                mx = simV
                    sum2 = sum2 + mx

            bma1 = (sum1+sum2)/ln
        else :
            bma1 = 0
        fuzzy_sim1.append(bma1)
        fuzzySc["{}-{}".format(i[0],i[1])]=round(bma1,6)
        
    
    fuzzy_sim = []
    fuzzyScN={}
    maxval = 0
    minval = 1000

    for x in fuzzy_sim1 :
        if x > maxval :
            maxval = x
        if x < minval :
            minval = x
        
    if maxval-minval!=0:dino=(maxval-minval)
    else:dino=1
    for ni,j in enumerate(fuzzy_sim1):
        bma = (j-minval)/dino
        bma = float("{0:.6f}".format(bma))
        fuzzy_sim.append(bma)
        axi=hs_intr[ni]
        fuzzyScN["{}-{}".format(axi[0],axi[1])]=bma
    #with open(f'{path}/RESULT/HS-{org}-{key}{ieaT}.json','w') as f :
    #    json.dump(fuzzyScN,f)

    print("{} time :".format(key), time.time() - start_time)      #   print(kxi,":: ",fuzzySc[kxi],":: ",fuzzyScN[kxi])
    return fuzzyScN

if __name__=="__main__":
    path=Path(os.getcwd()).parent
    if len (sys.argv) != 2 :
        print("@@@@@"*15)
        print("   Usage       : python SS_comp.py <org>")
        print("   <org>  : Target_Virus_Code     : example: SARS2,MERS.. .")
        print("@@@@@"*15)
        sys.exit (1)
    else:
        RD={}
        print("----------"*5)
        org="{}".format(sys.argv[1].strip())
        key="{}".format(sys.argv[2].strip())
        ieaT="{}".format(sys.argv[2].strip())
        print("\tYour input fasta file : {}  \n\tYour data Choice      : {}".format(fname,DataT))
        gowIEA = LoadIEA_annot(path)
        hs_intr=loadINTR(org)
        ica=LoadICA(path,org)
        for key in ['CC','MF','BP']:
          for ieaT in ["+","-"]:
            roots,path_len=loadPathL(path,key)       
            GOgraph,goAnc,goDsc = loadGraphData(path)
            
            RD[(key,ieaT)]= SS(path,org,key,hs_intr,ieaT,roots,path_len,ica,gowIEA)
        nwlr='H\tV\tC+\tC-\tF+\tF-\tB+\tB-\n'
        for ppair in hs_intr:
          pairp=f"{ppair[0]}-{ppair[1]}"
          lr=[]
          for key in ['CC','MF','BP']:
            for ieaT in ["+","-"]: lr.append(str(RD[(key,ieaT)][pairp]))
          nwlr+='{}\t{}\n'.format('\t'.join(ppair),'\t'.join(lr))
          lr=[]
          
        f = open(f'{path}/SCORES/Human_{org}.csv','w')
        f.write(nwlr);f.close()

        print("{} \n\t Hi!  Your Scores are ready.... \n\t Please check the Output Directory!\n{}\n".format("*****"*10,"*****"*10))