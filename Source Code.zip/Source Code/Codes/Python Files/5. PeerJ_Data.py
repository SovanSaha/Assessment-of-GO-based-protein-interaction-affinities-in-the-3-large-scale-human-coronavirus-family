
# coding: utf-8




import csv,json
import networkx as nx
import collections
import json
import numpy as np
import sys,os





Gn_All=nx.Graph()

with open('./Input_Files/Human-Host_PPI/MR_HsPth_Norm.csv') as csvfile:
    fr = csv.reader(csvfile, delimiter=',')
    for i,e in enumerate(fr):
        Gn_All.add_edge(e[0],e[1],weight=e[2])
print(len(Gn_All.edges())) 
print(len(Gn_All.nodes()))





GP=nx.Graph();GPf=nx.Graph()
with open('./Input_Files/PeerJ_Data/PIPE.csv') as csvfile:
    fr = csv.reader(csvfile, delimiter=',')
    for i,e in enumerate(fr):
        GP.add_edge(e[0],e[1])
print(len(GP.edges()))
print(len(GP.nodes()))

for e in Gn_All.edges():
    if GP.has_edge(e[0],e[1]):
        GPf.add_edge(e[0],e[1])
print(len(GPf.edges()))




GP=nx.Graph();GSf=nx.Graph()
with open('./Input_Files/PeerJ_Data/SPRINT.csv') as csvfile:
    fr = csv.reader(csvfile, delimiter=',')
    for i,e in enumerate(fr):
        GP.add_edge(e[0],e[1])
print(len(GP.edges()))
print(len(GP.nodes()))

for e in Gn_All.edges():
    if GP.has_edge(e[0],e[1]):
        GSf.add_edge(e[0],e[1])
print(len(GSf.edges()))




# Calculating Number of Bait and Prey protein for both the datasets. SPRINT data is given for example
CoV_Pipe=[];Human=[]
with open('./Input_Files/PeerJ_Data/SPRINT.csv') as csvfile:
    fr = csv.reader(csvfile, delimiter=',')
    for i,e in enumerate(fr):
        CoV_Pipe.append(e[0])
        Human.append(e[1])
CoV_Pipe=list(set(CoV_Pipe))
Human=list(set(Human))
print(len(Human))
print(len(CoV_Pipe))

