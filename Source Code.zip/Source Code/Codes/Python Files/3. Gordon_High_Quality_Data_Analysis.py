
# coding: utf-8

# In[ ]:


import csv,json
import networkx as nx
import collections
import json
import numpy as np
import sys,os




GH=nx.Graph()
Gn=nx.Graph();NormS=[];wt=[]

with open('./Input_Files/Gordon_Data/MR_GordonHQ_Score.csv') as csvfile:
    fr = csv.reader(csvfile, delimiter=',')
    for i,e in enumerate(fr):
        GH.add_edge(e[0],e[1],weight=e[2])
print(len(GH.edges()))
print(len(GH.nodes()))
for e in GH.edges():
        wt.append(float(GH[e[0]][e[1]]['weight']))
mxS=max(wt)
mnS=min(wt)
for e in GH.edges():
    lls=float(GH[e[0]][e[1]]['weight'])
    ns=(lls-mnS)/(mxS-mnS)
    NormS.append(ns)
    Gn.add_edge(e[0],e[1],weight=ns)
print(len(Gn.edges()))
print(len(Gn.nodes()))





GH=nx.Graph()
pds=[];GnC=nx.Graph();c=0
#GH is the Graph after applying Min-Max Weight upto three decimal places
with open('./Input_Files/Human-Host_PPI/MR_HsPth_Norm.csv') as csvfile:
    fr = csv.reader(csvfile, delimiter=',')
    for i,e in enumerate(fr):
        GH.add_edge(e[0],e[1],weight=e[2])
f=open("./Input_Files/Human-Host_PPI/SARS-CoV2_Protein.txt","r")
for ln in f:
    pd=ln.split('\n')[0]
    pds.append(pd)
print(type(pds))
for e in GH.edges():
    if (((e[0] in pds) and (e[1] not in pds)) or ((e[1] in pds )and (e[0] not in pds))):
        GnC.add_edge(e[0],e[1],weight=GH[e[0]][e[1]]['weight'])
print(len(GnC.nodes()))
print(len(GnC.edges()))


# In[ ]:


GNn=nx.Graph()
# GNn is the graph with different threshold. Here 0.15 threshold is given as example
for e in GnC.edges():
    if float(GnC[e[0]][e[1]]['weight'])>=0.1:
        GNn.add_edge(e[0],e[1],weight=GnC[e[0]][e[1]]['weight'])
print(len(GNn.nodes()))
print(len(GNn.edges()))




GHq=nx.Graph();G2=nx.Graph()
with open('./Input_Files/Gordon_Data/Gordon_HighQuality.csv') as csvfile:
    fr = csv.reader(csvfile, delimiter=',')
    for i,e in enumerate(fr):
        GHq.add_edge(e[0],e[1])
print(len(GHq.edges()))
print(len(GHq.nodes()))
for row in GHq.edges():
    if (GNn.has_edge(row[0],row[1])) or (GNn.has_edge(row[1],row[0])):
            G2.add_edge(row[0],row[1])
print(len(G2.edges()))
print(len(G2.nodes()))  
print(G2.nodes())

