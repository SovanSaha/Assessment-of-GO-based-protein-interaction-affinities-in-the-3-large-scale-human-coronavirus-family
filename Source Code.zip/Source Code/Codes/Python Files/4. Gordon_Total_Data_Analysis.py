
# coding: utf-8




import csv,json
import networkx as nx
import collections
import json
import numpy as np
import sys,os





GH=nx.Graph(); G1=nx.Graph()

with open('./Input_Files/Human-Host_PPI/MR_HsPth_Norm.csv') as csvfile:
    fr = csv.reader(csvfile, delimiter=',')
    for i,e in enumerate(fr):
        GH.add_edge(e[0],e[1],weight=e[2])
print(len(GH.edges())) 
print(len(GH.nodes()))
G1=nx.Graph()
# Score has been calculated under different threshold values. 0.09 is taken as example
for e in GH.edges():
    if float(GH[e[0]][e[1]]['weight'])>=0.09:
        G1.add_edge(e[0],e[1],weight=float(GH[e[0]][e[1]]['weight']))
print(len(G1.edges())) 
print(len(G1.nodes()))





pds=[]
f=open("./Input_Files/Human-Host_PPI/SARS-CoV2_Protein.txt","r")
for ln in f:
    pd=ln.split('\n')[0]
    pds.append(pd)
print(len(pds))





nCoV=[];Hm=[]
for n in G1.nodes():
    if n in pds:
        nCoV.append(n)
    else:
        Hm.append(n)
print(len(nCoV))
print(len(Hm))





NCL=[];HML=[]
#Gx is the Graph with individual cost
Gx=nx.Graph()
with open('./Input_Files/Gordon_Data/Gordon_Data_V2.csv') as csvfile:
#Gordon_Data_V2 contains bith Mapped and Unmapped Proteins 
    fr = csv.reader(csvfile, delimiter=',')
    for i,e in enumerate(fr):
        if i>0:
            Gx.add_edge(e[0],e[1])
            NCL.append(e[0])
            HML.append(e[1])

NCL=list(set(NCL))
HML=list(set(HML))
print("Total # of edges in Gordon Dataset::",len(Gx.edges()))
print("Total # of Nodes in Gordon Dataset::",len(Gx.nodes()))
print("Number of nCoV Proteins::",len(NCL))
print("Number of Human Proteins::",len(HML))





G2=nx.Graph()
for e in G1.edges():
    if Gx.has_edge(e[0],e[1]):
        G2.add_edge(e[0],e[1])
print("Intersected Edges::",len(G2.edges()))
print("Intersected Nodes::",len(G2.nodes()))

