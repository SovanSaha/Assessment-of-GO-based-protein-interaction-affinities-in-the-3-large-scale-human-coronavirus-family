
# coding: utf-8

# In[ ]:


import csv,json
import networkx as nx
import collections
import sys,os


GH=nx.Graph()
pds=[];GnC=nx.Graph();c=0
with open('./Input_Files/Human-Host_PPI/MR_HsPth_Norm.csv') as csvfile:
    fr = csv.reader(csvfile, delimiter=',')
    for i,e in enumerate(fr):
        GH.add_edge(e[0],e[1],weight=e[2])
#Human-nCoV interaction Network
f=open("./Human-Host_PPI/SARS-CoV2_Protein.txt","r")
for ln in f:
    pd=ln.split('\n')[0]
    pds.append(pd)
for e in GH.edges():
    if (((e[0] in pds) and (e[1] not in pds)) or ((e[1] in pds )and (e[0] not in pds))):
        GnC.add_edge(e[0],e[1],weight=GH[e[0]][e[1]]['weight'])
for e in GH.edges():
    if ((e[0] in pds) or (e[1] in pds)):
        GnC.add_edge(e[0],e[1],weight=GH[e[0]][e[1]]['weight'])
print(len(GnC.nodes()))
print(len(GnC.edges()))




#nCoV-nCoV interaction Network
GC=nx.Graph()
# GC is the n-Cov n-Cov Graph
for e in GH.edges():
    if ((e[0] in pds) and (e[1] in pds)):
        GC.add_edge(e[0],e[1],weight=GH[e[0]][e[1]]['weight'])
print(len(GC.nodes()))
print(len(GC.edges()))




#Human-human interaction Network
GHm=nx.Graph()

for e in GH.edges():
    if ((e[0] not in pds) and (e[1] not in pds)):
        GHm.add_edge(e[0],e[1],weight=GH[e[0]][e[1]]['weight'])
print(len(GHm.nodes()))
print(len(GHm.edges()))


# In[ ]:


GNn=nx.Graph()
# GNn is the graph with different threshold. Here 0.15 threshold is given as example
for e in GnC.edges():
    if float(GnC[e[0]][e[1]]['weight'])>=0.15:
        GNn.add_edge(e[0],e[1],weight=GnC[e[0]][e[1]]['weight'])
print(len(GNn.nodes()))
print(len(GNn.edges()))





PID_Hm=[]
PID_nC=[]
PID_CV=[]
for n in GNn.nodes():
    if n in Pid_H:
        PID_Hm.append(n)
    elif n in pds:
        PID_nC.append(n)
    else:
        PID_CV.append(n)
print("Human Protein Involved=>",len(PID_Hm))
print("nCoV Protein Involved=>",len(PID_nC))
print("Other Corona Virus Protein Involved=>",len(PID_CV))
# Total Number of nodes
PID_L=[]
for p in GNn.nodes():
    PID_L.append(p)
print(len(PID_L))

