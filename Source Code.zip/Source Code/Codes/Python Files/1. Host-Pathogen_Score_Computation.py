
# coding: utf-8



import csv,json
import networkx as nx
import collections
import sys,os



Gx=nx.Graph()
#Gx is the Graph with individual score
with open('./Input_Files/Human-Host_PPI/Human_CoV.csv') as csvfile:
    fr = csv.reader(csvfile, delimiter=',')
    for i,e in enumerate(fr):
        Gx.add_edge(e[0],e[1],weight=e[2:])
print(len(Gx.edges()))
print(len(Gx.nodes()))
f5=open('./Input_Files/Human-Host_PPI/MR_HsPth_Total1.csv','w')
f5.write('\n'.join('{},{},{:.3f}'.format(x[0],x[1],(float(Gx[x[0]][x[1]]['weight'][0])+float(Gx[x[0]][x[1]]['weight'][1])+float(Gx[x[0]][x[1]]['weight'][2])+float(Gx[x[0]][x[1]]['weight'][3])+float(Gx[x[0]][x[1]]['weight'][4])+float(Gx[x[0]][x[1]]['weight'][5]))) for x in Gx.edges()))
f5.close()



GHp=nx.Graph()
Gn=nx.Graph();NormS=[];wt=[]
#GHp is the Graph with total cost (adding all the annotations)
with open('./Input_Files/Human-Host_PPI/MR_HsPth_Total.csv') as csvfile:
    fr = csv.reader(csvfile, delimiter=',')
    for i,e in enumerate(fr):
        GHp.add_edge(e[0],e[1],weight=e[2])
#Gn is the graph having weight after applying Min-Max
for e in GHp.edges():
        wt.append(float(GHp[e[0]][e[1]]['weight']))
mxS=max(wt)
mnS=min(wt)
for e in GHp.edges():
    lls=float(GHp[e[0]][e[1]]['weight'])
    ns=(lls-mnS)/(mxS-mnS)
    NormS.append(ns)
    Gn.add_edge(e[0],e[1],weight=ns)
f5=open('./Input_Files/Human-Host_PPI/MR_HsPth_Norm.csv','w')
for i,x in enumerate(Gn.edges()):
    f5.write('{},{},{:3f}\n'.format(x[0],x[1],(float(Gn[x[0]][x[1]]['weight']))))
f5.close()  

