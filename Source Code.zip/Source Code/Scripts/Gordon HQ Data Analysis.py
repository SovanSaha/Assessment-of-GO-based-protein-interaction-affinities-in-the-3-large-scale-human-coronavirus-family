
# coding: utf-8

# In[3]:


import csv,json
import networkx as nx
import collections
import json
import numpy as np


# In[4]:


GH=nx.Graph()
#GH is the Graph after applying Min-Max Weight upto three decimal places
with open('./GordonHQ/MR_GordonHQ_Score.csv') as csvfile:
    fr = csv.reader(csvfile, delimiter=',')
    for i,e in enumerate(fr):
        GH.add_edge(e[0],e[1],weight=e[2])
print(len(GH.edges()))
print(len(GH.nodes()))


# In[6]:


Gn=nx.Graph();NormS=[];wt=[]
#Gn is the graph having weight after applying Min-Max
for e in GH.edges():
        wt.append(float(GH[e[0]][e[1]]['weight']))
mxS=max(wt)
mnS=min(wt)
for e in GH.edges():
    lls=float(GH[e[0]][e[1]]['weight'])
    ns=(lls-mnS)/(mxS-mnS)
    NormS.append(ns)
    Gn.add_edge(e[0],e[1],weight=ns)
print(len(Gn.edges()))
print(len(Gn.nodes()))


# In[49]:


lsv=[];lsh=[];G1=nx.Graph()
with open('./GordonHQ/Gordon_HighQuality.csv') as csvfile:
    fr = csv.reader(csvfile, delimiter=',')
    for i,e in enumerate(fr):
        if i>0:
            G1.add_edge(e[0],e[1])
            lsv.append(e[0])
            lsh.append(e[1])

lsv=list(set(lsv))
lsh=list(set(lsh))
print(len(lsv))
print(len(lsh))


# In[47]:


pds=[]
f=open("SARS-CoV2_Protein.txt","r")
for ln in f:
    pd=ln.split('\n')[0]
    pds.append(pd)
print(len(pds))


# In[52]:


G2=nx.Graph()
for e in Gn.edges():
    if G1.has_edge(e[0],e[1]) or G1.has_edge(e[1],e[0]):
        G2.add_edge(e[0],e[1],weight=float(Gn[e[0]][e[1]]['weight']))
print(len(G2.edges()))

