
# coding: utf-8

# In[1]:


import csv,json
import networkx as nx
import collections
import json
import numpy as np


# In[2]:


G_All=nx.Graph()
with open('MR_HsPth_All.csv') as csvfile:
    fr = csv.reader(csvfile, delimiter=',')
    for i,e in enumerate(fr):
        G_All.add_edge(e[0],e[1],weight=e[2])
print(len(G_All.edges()))
print(len(G_All.nodes()))


# In[3]:


Gn_All=nx.Graph();NormS=[];wt=[]
#Gn is the graph having weight after applying Min-Max
for e in G_All.edges():
        wt.append(float(G_All[e[0]][e[1]]['weight']))
mxS=max(wt)
mnS=min(wt)
for e in G_All.edges():
    lls=float(G_All[e[0]][e[1]]['weight'])
    ns=(lls-mnS)/(mxS-mnS)
    NormS.append(ns)
    Gn_All.add_edge(e[0],e[1],weight=ns)
print(len(Gn_All.edges))
print(len(Gn_All.nodes))


# In[4]:


GP=nx.Graph()
with open('./PeerJ Data/PIPE.csv') as csvfile:
    fr = csv.reader(csvfile, delimiter=',')
    for i,e in enumerate(fr):
        GP.add_edge(e[0],e[1])
print(len(GP.edges()))
print(len(GP.nodes()))


# In[7]:


GPf=nx.Graph()
for e in Gn_All.edges():
    if GP.has_edge(e[0],e[1]):
        GPf.add_edge(e[0],e[1])
print(len(GPf.edges()))


# In[8]:


GP=nx.Graph()
with open('./PeerJ Data/SPRINT.csv') as csvfile:
    fr = csv.reader(csvfile, delimiter=',')
    for i,e in enumerate(fr):
        GP.add_edge(e[0],e[1])
print(len(GP.edges()))
print(len(GP.nodes()))


# In[9]:


GSf=nx.Graph()
for e in Gn_All.edges():
    if GP.has_edge(e[0],e[1]):
        GSf.add_edge(e[0],e[1])
print(len(GSf.edges()))


# In[4]:


CoV_Pipe=[];Human=[]
with open('./PeerJ Data/SPRINT.csv') as csvfile:
    fr = csv.reader(csvfile, delimiter=',')
    for i,e in enumerate(fr):
        CoV_Pipe.append(e[0])
        Human.append(e[1])
CoV_Pipe=list(set(CoV_Pipe))
Human=list(set(Human))
print(len(Human))
print(len(CoV_Pipe))

