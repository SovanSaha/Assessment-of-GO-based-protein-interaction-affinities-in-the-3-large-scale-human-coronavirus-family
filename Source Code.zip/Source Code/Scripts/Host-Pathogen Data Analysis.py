
# coding: utf-8

# In[2]:


import csv,json
import networkx as nx
import collections


# In[3]:


Gx=nx.Graph()
#Gx is the Graph with individual cost
with open('Human_CoV.csv') as csvfile:
    fr = csv.reader(csvfile, delimiter=',')
    for i,e in enumerate(fr):
        Gx.add_edge(e[0],e[1],weight=e[2:])
print(len(Gx.edges()))
print(len(Gx.nodes()))
f5=open('MR_HsPth_Total1.csv','w')
f5.write('\n'.join('{},{},{:.3f}'.format(x[0],x[1],(float(Gx[x[0]][x[1]]['weight'][0])+float(Gx[x[0]][x[1]]['weight'][1])+float(Gx[x[0]][x[1]]['weight'][2])+float(Gx[x[0]][x[1]]['weight'][3])+float(Gx[x[0]][x[1]]['weight'][4])+float(Gx[x[0]][x[1]]['weight'][5]))) for x in Gx.edges()))
f5.close()


# In[3]:


GHp=nx.Graph()
#GHp is the Graph with total cost (adding all the annotations)
with open('MR_HsPth_Total.csv') as csvfile:
    fr = csv.reader(csvfile, delimiter=',')
    for i,e in enumerate(fr):
        GHp.add_edge(e[0],e[1],weight=e[2])


# In[5]:


Gn=nx.Graph();NormS=[];wt=[]
#Gn is the graph having weight after applying Min-Max
for e in GHp.edges():
        wt.append(float(GHp[e[0]][e[1]]['weight']))
mxS=max(wt)
mnS=min(wt)
for e in GHp.edges():
    lls=float(GHp[e[0]][e[1]]['weight'])
    ns=(lls-mnS)/(mxS-mnS)
    NormS.append(ns)
    Gn.add_edge(e[0],e[1],weight=ns)


# In[45]:


f5=open('MR_HsPth_Norm.csv','w')
for i,x in enumerate(Gn.edges()):
    f5.write('{},{},{:3f}\n'.format(x[0],x[1],(float(Gn[x[0]][x[1]]['weight']))))
f5.close()


# In[3]:


GH=nx.Graph()
#GH is the Graph after applying Min-Max Weight upto three decimal places
with open('MR_HsPth_Norm.csv') as csvfile:
    fr = csv.reader(csvfile, delimiter=',')
    for i,e in enumerate(fr):
        GH.add_edge(e[0],e[1],weight=e[2])
        


# In[8]:


#Human-nCoV interaction Network
pds=[];GnC=nx.Graph();c=0
f=open("SARS-CoV2_Protein.txt","r")
for ln in f:
    pd=ln.split('\n')[0]
    pds.append(pd)
print(type(pds))
for e in GH.edges():
    if (((e[0] in pds) and (e[1] not in pds)) or ((e[1] in pds )and (e[0] not in pds))):
        GnC.add_edge(e[0],e[1],weight=GH[e[0]][e[1]]['weight'])
print(len(GnC.nodes()))
print(len(GnC.edges()))


# In[8]:


for e in GH.edges():
    if ((e[0] in pds) or (e[1] in pds)):
        GnC.add_edge(e[0],e[1],weight=GH[e[0]][e[1]]['weight'])
print(len(GnC.nodes()))
print(len(GnC.edges()))


# In[10]:


#nCoV-nCoV interaction Network
GC=nx.Graph()
# GC is the n-Cov n-Cov Graph
for e in GH.edges():
    if ((e[0] in pds) and (e[1] in pds)):
        GC.add_edge(e[0],e[1],weight=GH[e[0]][e[1]]['weight'])
print(len(GC.nodes()))
print(len(GC.edges()))


# In[12]:


#Human-human interaction Network
GHm=nx.Graph()

for e in GH.edges():
    if ((e[0] not in pds) and (e[1] not in pds)):
        GHm.add_edge(e[0],e[1],weight=GH[e[0]][e[1]]['weight'])
print(len(GHm.nodes()))
print(len(GHm.edges()))


# In[5]:


GNn=nx.Graph()# GNn is the graph with 0.15 threshold
for e in GnC.edges():
    if float(GnC[e[0]][e[1]]['weight'])>=0.15:
        GNn.add_edge(e[0],e[1],weight=GnC[e[0]][e[1]]['weight'])
print(len(GNn.nodes()))
print(len(GNn.edges()))
#print(GNn.nodes())
#print(GNn.edges())


# In[2]:


f5=open('Human_nCoV_0.15.csv','w')
for i,x in enumerate(GNn.edges()):
    f5.write('{},{},{:3f}\n'.format(x[0],x[1],(float(GNn[x[0]][x[1]]['weight']))))
f5.close()


# In[ ]:


Pid_H=[]#Human Protein List
f=open("Human_proteins.txt","r")
for ln in f:
    pd=ln.split("\n")[0].split("\t")[0]
    Pid_H.append(pd)
print(len(Pid_H))


# In[6]:


Pid_H=[]#Human Protein List
f=open("Human_proteins.txt","r")
for ln in f:
    pd=ln.split("\n")[0].split("\t")[0]
    Pid_H.append(pd)
print(len(Pid_H))


# In[9]:


PID_Hm=[]
PID_nC=[]
PID_CV=[]
for n in GH.nodes():
    if n in Pid_H:
        PID_Hm.append(n)
    elif n in pds:
        PID_nC.append(n)
    else:
        PID_CV.append(n)
print("Human Protein Involved=>",len(PID_Hm))
print("nCoV Protein Involved=>",len(PID_nC))
print("Other Corona Virus Protein Involved=>",len(PID_CV))


# In[127]:


f=open("Covid_Protein_0.15.csv","w")
for n in PID_CV:
    f.write('{}\n'.format(n))
f.close()


# In[17]:


PID_L=[]
for p in GNn.nodes():
    PID_L.append(p)
print(len(PID_L))


# In[155]:


GL1=nx.Graph();pdl=[]
f=open("L-1_Human_Spreader.txt","r")
for r in f:
    pd=r.split("\n")[0]
    pdl.append(pd)
print(len(pdl))


# In[157]:


def intersection(PID_L, pdl):
    lst3 = [value for value in PID_L if value in pdl]
    return lst3
print(intersection(PID_L, pdl))


# # Gordon's Data

# In[27]:


GrN=nx.Graph();G1=nx.Graph()
with open('Gordon_Data_Graph.csv') as csvfile:
    fr = csv.reader(csvfile, delimiter=',')
    for i,e in enumerate(fr):
        GrN.add_edge(e[0],e[1])
print(len(GrN.edges()))
print(len(GrN.nodes()))
for row in GrN.edges():
    if (GNn.has_edge(row[0],row[1])) or (GNn.has_edge(row[1],row[0])):
            G1.add_edge(row[0],row[1])
print(len(G1.edges()))
print(len(G1.nodes()))   


# In[8]:


PID_Gr_H=[];PID_Gr_C=[]
with open('Gordon_Data_Graph.csv') as csvfile:#Gordon_Data_UP
    fr = csv.reader(csvfile, delimiter=',')
    for i,e in enumerate(fr):
        PID_Gr_H.append(e[1])
        PID_Gr_C.append(e[0])
PID_Gr_H=list(set(PID_Gr_H))
PID_Gr_C=list(set(PID_Gr_C))
print(len(PID_Gr_H))
print(len(PID_Gr_C))


# In[30]:


PID_Gr_H=[];PID_Gr_C=[]
with open('Gordon_Data_Graph.csv') as csvfile:
    fr = csv.reader(csvfile, delimiter=',')
    for i,e in enumerate(fr):
        PID_Gr_H.append(e[1])
        PID_Gr_C.append(e[0])
PID_Gr_H=list(set(PID_Gr_H))
PID_Gr_C=list(set(PID_Gr_C))
print(len(PID_Gr_H))
print(len(PID_Gr_C))


# In[31]:


PID_Fz_H=[];PID_Fz_C=[]
for row in G1.nodes():
    if (row in PID_Hm):# or (row in PID_Hm):
        PID_Fz_H.append(row)
    if (row in PID_nC):#or (row in PID_nC):
        PID_Fz_C.append(row)
PID_Fz_H=list(set(PID_Fz_H))
PID_Fz_C=list(set(PID_Fz_C))
print(len(PID_Fz_H))
print(len(PID_Fz_C))


# # Comparison with High Quality Data(Gordon's Data)

# In[23]:


GHq=nx.Graph();G2=nx.Graph()
with open('Gordon_HighQuality.csv') as csvfile:
    fr = csv.reader(csvfile, delimiter=',')
    for i,e in enumerate(fr):
        GHq.add_edge(e[0],e[1])
print(len(GHq.edges()))
print(len(GHq.nodes()))
for row in GHq.edges():
    if (GNn.has_edge(row[0],row[1])) or (GNn.has_edge(row[1],row[0])):
            G2.add_edge(row[0],row[1])
print(len(G2.edges()))
print(len(G2.nodes()))  
print(G2.nodes())


# In[32]:


PID_Fz_H=[];PID_Fz_C=[]
for row in G2.nodes():
    if (row in PID_Hm):# or (row in PID_Hm):
        PID_Fz_H.append(row)
    if (row in PID_nC):#or (row in PID_nC):
        PID_Fz_C.append(row)
PID_Fz_H=list(set(PID_Fz_H))
PID_Fz_C=list(set(PID_Fz_C))
print(len(PID_Fz_H))
print(len(PID_Fz_C))
print(PID_Fz_C)
print(PID_Fz_H)

