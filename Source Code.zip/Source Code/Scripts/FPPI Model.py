
# coding: utf-8

# In[1]:


import csv,json
import networkx as nx
import collections
import json
import numpy as np


# In[5]:


D={};pdl=[]
with open('./FPPI_HUMAN/Human_UP.tsv','r') as f :
        fr=csv.reader(f, delimiter='\t')
        for i,row in enumerate(fr):
            if i>0:
                if len(row[4])>0:
                    D[row[0]]=row[4]
                else:
                    pdl.append(row[0])
f=open('./FPPI_HUMAN/proteins.txt','w')
for d in D:
    f.write(d+'	'+D[d]+'\n')
f.close()
print(len(D))


# In[4]:


def parseIEAtype():
    prt=[]
    with open('./FPPI_HUMAN/Human_Prot.txt','r') as f :
        for ln in f:
            prt.append(ln.split()[0])
           # print(ln)
            #break
       # prt = json.load(f)

    print(len(prt))
    f = open("./FPPI_HUMAN/Human_Prot_Details.txt","r")
    
    f1 = open("./FPPI_HUMAN/All_ProtGO_IEA-parsed.txt","w+")
    listN = []
    for line in f:
        if line.startswith("AC"):
            x = line.split(";")
            y = x[0].split("   ")
            if y[1] in prt :
                listN.append(y[1])
                k = listN.index(y[1])
        if line.startswith("DR   GO"):
            if y[1] not in prt :
                f1.write("\t".join((listN[k],line)))
            else :
                f1.write("\t".join((y[1],line)))

    f.close()
    f1.close()
    f = open("./FPPI_HUMAN/All_ProtGO_IEA-parsed.txt","r")
    #f1 = open("./complete_Mus_musculus/mouse_protein_GO_details.txt","a")
    f1 = open("./FPPI_HUMAN/prot_details.txt","w+")
    for line in f.readlines() :
        x = line.strip("\n").split("\t")
        y = x[1].split(";")
        y[2] = y[2].split(":")
        y[3] = y[3].split(":")
        f1.write("\t".join((x[0],y[1],y[2][0],y[3][0]))+"\n")
    f.close()
    f1.close()

parseIEAtype()

