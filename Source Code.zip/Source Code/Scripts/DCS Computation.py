
# coding: utf-8

# In[1]:


import csv,json
import networkx as nx
import collections
import json
import numpy as np


# In[19]:


s='ID\tGene Name\tUniprot ID\tSpecies\tDrug ID\n'
with open('./DCS/Updated_DB/all.csv') as csvfile:
    fr = csv.reader(csvfile,delimiter=',')
    for i,e in enumerate(fr):
        if i>0:
            s+='{}\t{}\t{}\t{}\t{}\n'.format(e[0],e[2],e[5],e[11],e[12])
f=open("./DCS/Updated_DB/all.txt","w")
f.write(s);f.close()


# In[8]:


gene=[]
f=open("./DCS/Protein_Gene_mapping_0.1.txt","r")
for i,ln in enumerate(f):
    if i>0:
        lne=ln.split("\n")[0].split("\t")[3].split("_")[0]
        gene.append(lne)
print(len(gene))
s=''
for n in gene:
    s+='{}\n'.format(n)
f=open("./DCS/Human_Total_Gene_List_0.1.txt","w")
f.write(s);f.close()


# In[11]:




import operator
from collections import OrderedDict 


f7=open('./DCS/Human_Total_Gene_List_0.1.txt','r')
fds=f7.readlines()

f8=open('./DCS/Updated_DB/all.txt','r')
ghf=f8.readlines()

f76=open('./DCS/3.txt','w')

str1=[]

for t in fds:
    t=t.strip('\n')
    str1.append(t)
    
#str1=list(set(str1))
#print(len(str1))

drug_id=[]
#drug_name=[]

for e in str1:
    e=e.strip('\n')
    s2=''
    s2+=e
    s2=s2.strip()
    for r in ghf:
        r=r.strip('\n')
        hld=r.split('\t')
        s1=''
        s1+=hld[1]
        s1=s1.strip()
        if s2==s1:         
            if ';' in hld[4]:
                tc=hld[4].split(';')
                
                #drug_name.append(hld[2])
                for r in tc:
                    r=r.strip('\n')
                    sw=''
                    sw+=r
                    sw=sw.strip()
                    drug_id.append(s2+'|'+sw+'|'+hld[3])
            else:
                sw=''
                sw+=hld[4]
                sw=sw.strip()
                drug_id.append(s2+'|'+sw+'|'+hld[3])
            
#drug_name1=list(set(drug_name))
drug_id1=list(set(drug_id))

#print ('total no. of unique drugs:'+str(len(drug_id1)))

#print ('unique drugs:'+str(drug_id1))

'''d1={}
for t in drug_name1:
    t=t.strip('\n')
    d1[t]=drug_name.count(t)
    
sorted_d = OrderedDict(sorted(d1.items(), key=operator.itemgetter(1),reverse=True))

for nm, vl in sorted_d.items(): 
    print(nm+"|"+str(vl)+'\n') '''
    
d2={}
for t in drug_id1:
    t=t.strip('\n')
    d2[t]=drug_id.count(t)
    
sorted_d = OrderedDict(sorted(d2.items(), key=operator.itemgetter(1),reverse=True))

for nm, vl in sorted_d.items(): 
    f76.writelines(nm+'\n')
    #print(nm+"|"+str(vl)+'\n') 
    
f76.close()            

f76=open('./DCS/3.txt','r')
eq=f76.readlines()

fg=open('./DCS/drugbank idnamemapping.txt','r')
rd=fg.readlines()

dc=open('./DCS/3_new.txt','w')

for t in eq:
    t=t.strip('\n')
    f=t.split('|')
    s1=''
    s1+=f[1]
    s1=s1.strip()
    for g in rd:
        g=g.strip('\n')
        cv=g.split('\t')
        s2=''
        s2+=cv[0]
        s2=s2.strip()
        if s1==s2:
            dc.writelines(t+'|'+cv[1]+'\n')
            
            
dc.close()

dcfg=open('./DCS/3_new.txt','r')
dg_ln=dcfg.readlines()
dg_nm=[]

for t in dg_ln:
    t=t.strip('\n')
    f=t.split('|')
    dg_nm.append(f[1])
    
dg_nm=list(set(dg_nm))
#print(len(dg_nm))
s=''
f=open("./DCS/Drug_DCS_Score_0.1_Up.csv","w")
for e in dg_nm:
    count=0
    s1=[]
    for t in dg_ln:
        t=t.strip('\n')
        f=t.split('|')
        if e==f[1]:
            count+=1
            fi=''
            fi+=f[3]
            s1.append(fi)
    list_of_strings = list(set(s1))
    joined_string = " ".join(list_of_strings)
    print(e+'|'+str(count)+'|'+joined_string)
    s+='{},{},{}\n'.format(e,str(count),joined_string)
f.write(s)
f.close()


# In[12]:


f=open("./DCS/Drug_DCS_Score_0.1_Up.csv","w")
f.write(s);f.close()

