
# coding: utf-8

# In[1]:


import csv,json
import networkx as nx
import collections
import json
import numpy as np


# In[2]:


ls_SARS2=[];ls_SARS=[];ls_HKU3=[];ls_RP3=[];ls_MERS=[];ls_HKU5=[];ls_MUR=[];ls_BOV=[]
ls_RAT=[];ls_HKU4=[];ls_BAT=[]
with open('./Total_Covid_Virus/Corona Virus Stat.csv') as csvfile:
    fr = csv.reader(csvfile, delimiter=',')
    for i,e in enumerate(fr):
        #print(e[0])
        if i>0:
            if e[0]=='Severe acute respiratory syndrome coronavirus 2':
                ls_SARS2=e[1].split(',')
            if e[0]=='Severe acute respiratory syndrome coronavirus':
                #ls_SARS='{}\n'.format(e[1].split(',')[0])
                ls_SARS=e[1].split(',')
            if e[0]=='Bat coronavirus HKU3':
                #ls_SARS='{}\n'.format(e[1].split(',')[0])
                ls_HKU3=e[1].split(',')
            if e[0]=='Bat coronavirus Rp3/2004':
                #ls_SARS='{}\n'.format(e[1].split(',')[0])
                ls_RP3=e[1].split(',')
            if e[0]=='Middle East respiratory syndrome-related coronavirus':
                #ls_SARS='{}\n'.format(e[1].split(',')[0])
                ls_MERS=e[1].split(',')
            if e[0]=='Bat coronavirus HKU5':
                #ls_SARS='{}\n'.format(e[1].split(',')[0])
                ls_HKU5=e[1].split(',')
            if e[0]=='Murine coronavirus':
                #ls_SARS='{}\n'.format(e[1].split(',')[0])
                ls_MUR=e[1].split(',')
            if e[0]=='Bovine coronavirus':
                #ls_SARS='{}\n'.format(e[1].split(',')[0])
                ls_BOV=e[1].split(',')
            if e[0]=='Rat coronavirus':
                #ls_SARS='{}\n'.format(e[1].split(',')[0])
                ls_RAT=e[1].split(',')
            if e[0]=='Bat coronavirus HKU4':
                #ls_SARS='{}\n'.format(e[1].split(',')[0])
                ls_HKU4=e[1].split(',')
            if e[0]=='Bat coronavirus 133/2005':
                #ls_SARS='{}\n'.format(e[1].split(',')[0])
                ls_BAT=e[1].split(',')
                
print(len(ls_SARS2))               
print(len(ls_SARS))
print(len(ls_HKU3))
print(len(ls_RP3))
print(len(ls_MERS))
print(len(ls_HKU5))
print(len(ls_MUR))
print(len(ls_BOV))
print(len(ls_RAT))
print(len(ls_HKU4))
print(len(ls_BAT))
 


# In[3]:


f=open("./Total_Covid_Virus/Sars_CoV2.txt","w")
s=''
for l in ls_SARS2:
    s+='{}\n'.format(l)
f.write(s);f.close()
#print(ls_SARS)


# In[4]:


ls_Total=ls_SARS2+ls_SARS+ls_HKU3+ls_RP3+ls_MERS+ls_HKU5+ls_MUR+ls_BOV+ls_RAT+ls_HKU4+ls_BAT
print(len(ls_Total))


# In[7]:


f=open("./Total_Covid_Virus/Total_Virus_Count.txt","w")
s=''
for l in ls_Total:
    s+='{}\n'.format(l)
f.write(s);f.close()


# In[52]:


D={};pdl=[]
with open('./Total_Covid_Virus/Total_Covid_Organism.tab','r') as f :
        fr=csv.reader(f, delimiter='\t')
        for i,row in enumerate(fr):
            if i>0:
                if len(row[4])>0:
                    D[row[0]]=row[4]
                else:
                    pdl.append(row[0])
f=open('./Total_Covid_Virus/proteins.txt','w')
for d in D:
    f.write(d+'	'+D[d]+'\n')
f.close()
print(len(D))


# In[53]:


def parseIEAtype():
    prt=[]
    with open('./Total_Covid_Virus/Total_Virus_Count.txt','r') as f :
        for ln in f:
            prt.append(ln.split()[0])
           # print(ln)
            #break
       # prt = json.load(f)

    print(len(prt))
    f = open("./Total_Covid_Virus/CoV_Prot_Details.txt","r")
    
    f1 = open("./Total_Covid_Virus/All_ProtGO_IEA-parsed.txt","w+")
    listN = []
    for line in f:
        if line.startswith("AC"):
            x = line.split(";")
            y = x[0].split("   ")
            if y[1] in prt :
                listN.append(y[1])
                k = listN.index(y[1])
        if line.startswith("DR   GO"):
            if y[1] not in prt :
                f1.write("\t".join((listN[k],line)))
            else :
                f1.write("\t".join((y[1],line)))

    f.close()
    f1.close()
    f = open("./Total_Covid_Virus/All_ProtGO_IEA-parsed.txt","r")
    #f1 = open("./complete_Mus_musculus/mouse_protein_GO_details.txt","a")
    f1 = open("./Total_Covid_Virus/prot_details.txt","w+")
    for line in f.readlines() :
        x = line.strip("\n").split("\t")
        y = x[1].split(";")
        y[2] = y[2].split(":")
        y[3] = y[3].split(":")
        f1.write("\t".join((x[0],y[1],y[2][0],y[3][0]))+"\n")
    f.close()
    f1.close()

parseIEAtype()


# # Result Analysis

# In[3]:


Gx=nx.Graph()
#Gx is the Graph with individual cost
with open('./All_Covid/MR_All.csv') as csvfile:
    fr = csv.reader(csvfile, delimiter=',')
    for i,e in enumerate(fr):
        Gx.add_edge(e[0],e[1],weight=e[2:])
print(len(Gx.edges()))
print(len(Gx.nodes()))
f5=open('MR_HsPth_All.csv','w')
f5.write('\n'.join('{},{},{:.3f}'.format(x[0],x[1],(float(Gx[x[0]][x[1]]['weight'][0])+float(Gx[x[0]][x[1]]['weight'][1])+float(Gx[x[0]][x[1]]['weight'][2])+float(Gx[x[0]][x[1]]['weight'][3])+float(Gx[x[0]][x[1]]['weight'][4])+float(Gx[x[0]][x[1]]['weight'][5]))) for x in Gx.edges()))
f5.close()


# In[ ]:


165721924
19376


# In[7]:


G_All=nx.Graph()
with open('MR_HsPth_All.csv') as csvfile:
    fr = csv.reader(csvfile, delimiter=',')
    for i,e in enumerate(fr):
        G_All.add_edge(e[0],e[1],weight=e[2])
print(len(G_All.edges()))
print(len(G_All.nodes()))


# # Score Normalization

# In[8]:


Gn_All=nx.Graph();NormS=[];wt=[]
#Gn is the graph having weight after applying Min-Max
for e in G_All.edges():
        wt.append(float(G_All[e[0]][e[1]]['weight']))
mxS=max(wt)
mnS=min(wt)
for e in G_All.edges():
    lls=float(G_All[e[0]][e[1]]['weight'])
    ns=(lls-mnS)/(mxS-mnS)
    NormS.append(ns)
    Gn_All.add_edge(e[0],e[1],weight=ns)
print(len(Gn_All.edges))
print(len(Gn_All.nodes))


# In[9]:


ls_SARS=[];ls_HKU3=[];ls_RP3=[];ls_MERS=[];ls_HKU5=[];ls_MUR=[];ls_BOV=[]
ls_RAT=[];ls_HKU4=[];ls_BAT=[]


# In[9]:


Pid_H=[]#Human Protein List
f=open("Human_proteins.txt","r")
for ln in f:
    pd=ln.split("\n")[0].split("\t")[0]
    Pid_H.append(pd)
print(len(Pid_H))


# In[10]:


G_SARS2=nx.Graph();G_SARS=nx.Graph();G_HKU3=nx.Graph();G_RP3=nx.Graph();G_MERS=nx.Graph();G_HKU5=nx.Graph()
G_MUR=nx.Graph();G_BOV=nx.Graph();G_RAT=nx.Graph();G_HKU4=nx.Graph();G_BAT=nx.Graph()

for i,e in enumerate(Gn_All.edges()):
    if Gn_All[e[0]][e[1]]['weight']>0.1:
        if( e[0] in ls_SARS2 and e[1] in Pid_H) or (e[1] in ls_SARS2 and e[0] in Pid_H):
            G_SARS2.add_edge(e[0],e[1],weight=Gn_All[e[0]][e[1]]['weight'])
        if( e[0] in ls_SARS and e[1] in Pid_H) or (e[1] in ls_SARS and e[0] in Pid_H):
            G_SARS.add_edge(e[0],e[1],weight=Gn_All[e[0]][e[1]]['weight'])
        if (e[0] in ls_HKU3 and e[1] in Pid_H) or (e[1] in ls_HKU3 and e[0] in Pid_H):
            G_HKU3.add_edge(e[0],e[1],weight=Gn_All[e[0]][e[1]]['weight'])
        if (e[0] in ls_RP3 and e[1] in Pid_H) or (e[1] in ls_RP3 and e[0] in Pid_H):
            G_RP3.add_edge(e[0],e[1],weight=Gn_All[e[0]][e[1]]['weight'])
        if (e[0] in ls_MERS and e[1] in Pid_H) or (e[1] in ls_MERS and e[0] in Pid_H):
            G_MERS.add_edge(e[0],e[1],weight=Gn_All[e[0]][e[1]]['weight'])
        if (e[0] in ls_HKU5 and e[1] in Pid_H) or (e[1] in ls_HKU5 and e[0] in Pid_H):
            G_HKU5.add_edge(e[0],e[1],weight=Gn_All[e[0]][e[1]]['weight'])
        if (e[0] in ls_MUR and e[1] in Pid_H) or (e[1] in ls_MUR and e[0] in Pid_H):
            G_MUR.add_edge(e[0],e[1],weight=Gn_All[e[0]][e[1]]['weight'])
        if (e[0] in ls_BOV and e[1] in Pid_H) or (e[1] in ls_BOV and e[0] in Pid_H):
            G_BOV.add_edge(e[0],e[1],weight=Gn_All[e[0]][e[1]]['weight'])
        if (e[0] in ls_RAT and e[1] in Pid_H) or (e[1] in ls_RAT and e[0] in Pid_H):
            G_RAT.add_edge(e[0],e[1],weight=Gn_All[e[0]][e[1]]['weight'])
        if (e[0] in ls_HKU4 and e[1] in Pid_H) or (e[1] in ls_HKU4 and e[0] in Pid_H):
            G_HKU4.add_edge(e[0],e[1],weight=Gn_All[e[0]][e[1]]['weight'])
        if (e[0] in ls_BAT and e[1] in Pid_H) or (e[1] in ls_BAT and e[0] in Pid_H):
            G_BAT.add_edge(e[0],e[1],weight=Gn_All[e[0]][e[1]]['weight'])
print("SARS2 Edges==>",len(G_SARS2.edges()))
print("SARS2 Nodes==>",len(G_SARS2.nodes()))
print("SARS Edges==>",len(G_SARS.edges()))
print("SARS Nodes==>",len(G_SARS.nodes()))
print("HKU3 Edges==>",len(G_HKU3.edges()))
print("HKU3 Nodes==>",len(G_HKU3.nodes()))
print("RP3 Edges==>",len(G_RP3.edges()))
print("RP3 Nodes==>",len(G_RP3.nodes()))
print("MERS Edges==>",len(G_MERS.edges()))
print("MERS Nodes==>",len(G_MERS.nodes()))
print("HKU5 Edges==>",len(G_HKU5.edges()))
print("HKU5 Nodes==>",len(G_HKU5.nodes()))
print("MUR Edges==>",len(G_MUR.edges()))
print("MUR Nodes==>",len(G_MUR.nodes()))
print("BOV Edges==>",len(G_BOV.edges()))
print("BOV Nodes==>",len(G_BOV.nodes()))
print("RAT Edges==>",len(G_RAT.edges()))
print("RAT Nodes==>",len(G_RAT.nodes()))
print("HKU4 Edges==>",len(G_HKU4.edges()))
print("HKU4 Nodes==>",len(G_HKU4.nodes()))
print("BAT Edges==>",len(G_BAT.edges()))
print("BAT Nodes==>",len(G_BAT.nodes()))
print("SARS Edges==>",len(G_SARS.edges()))
print("SARS Nodes==>",len(G_SARS.nodes()))


# In[11]:


hm0=set();hm1=set();hm2=set();hm3=set();hm4=set();hm5=set();hm6=set();hm7=set();hm8=set();hm9=set();hm10=set()

for n in G_SARS2.nodes():
    if n in Pid_H:
        hm0.add(n)
for n in G_SARS.nodes():
    if n in Pid_H:
        hm1.add(n)
for n in G_HKU3.nodes():
    if n in Pid_H:
        hm2.add(n)
for n in G_RP3.nodes():
    if n in Pid_H:
        hm3.add(n)
for n in G_MERS.nodes():
    if n in Pid_H:
        hm4.add(n)
for n in G_HKU5.nodes():
    if n in Pid_H:
        hm5.add(n)
for n in G_MUR.nodes():
    if n in Pid_H:
        hm6.add(n)
for n in G_BOV.nodes():
    if n in Pid_H:
        hm7.add(n)
for n in G_RAT.nodes():
    if n in Pid_H:
        hm8.add(n)
for n in G_HKU4.nodes():
    if n in Pid_H:
        hm9.add(n)
for n in G_BAT.nodes():
    if n in Pid_H:
        hm10.add(n)
print("Host Nodes With SARS2::",len(hm0))
print("Host Nodes With SARS::",len(hm1))
print("Host Nodes With HKU3::",len(hm2))
print("Host Nodes With RP3::",len(hm3))
print("Host Nodes With MERS::",len(hm4))
print("Host Nodes With HKU5::",len(hm5))
print("Host Nodes With MUR::",len(hm6))
print("Host Nodes With BOV",len(hm7))
print("Host Nodes With RAT",len(hm8))
print("Host Nodes With HKU4",len(hm9))
print("Host Nodes With BAT::",len(hm10))


# In[12]:


hmm0=set();hmm1=set();hmm2=set();set_lst1=[];set_lst2=[];set_lst3=[]
hmm0=set.intersection(hm0,hm1,hm4)
hmm1=set.intersection(hm2,hm3,hm5,hm9,hm10)
hmm2=set.intersection(hm6,hm7,hm8)
set_lst1=list(set(hmm0))
set_lst2=list(set(hmm1))
set_lst3=list(set(hmm2))
print(len(set_lst1))
print(len(set_lst2))
print(len(set_lst3))


# In[13]:


hmm=set();set_list=[]
hmm=set.intersection(hmm0,hmm1,hmm2)
set_list=list(set(hmm)) 
print(len(hmm))
print(len(set_list))


# In[17]:


s=''
for n in set_lst3:
    s+='{}\n'.format(n)
f=open("./Total_Covid_Virus/TH_0.1/Vulnerable_Human_Proteins_MUR_BOV_RAT.txt","w")
f.write(s);f.close()  


# In[128]:


s=''
for n in set_lst:
    s+='{}\n'.format(n)
f=open("./Total_Covid_Virus/Corona_Family.txt","w")
f.write(s);f.close()  


# In[98]:


s=''
for ls in hmm0:
    s+="{}\n".format(ls)
f=open("./Total_Covid_Virus/Individual Protein List/nCoV_SARS_MERS.txt","w")
f.write(s);f.close()


# In[96]:


set_Host=set();set_lst=[]
set_Host=set.intersection(hmm0,hmm1,hm6,hm7,hm8)
set_lst=list(set_Host)
print(len(set_lst))


# In[85]:


set_Host=set();set_lst=[]
set_Host=set.intersection(hm0,hm1,hm2,hm3,hm4,hm5,hm6,hm7,hm8,hm9,hm10)
set_lst=list(set_Host)
print(len(set_lst))


# In[113]:


set_Host=set();set_lst1=[];set_lst2=[];set_lst3=[]
set_Host=set.intersection(hm0,hm1,hm4)
set_lst=list(set_Host)
print(len(set_lst))


# In[114]:


s=''
for n in set_lst:
    s+='{}\n'.format(n)
f=open("./Total_Covid_Virus/SARS-CoV2_SARS-CoV_MERS.txt","w")
f.write(s);f.close()    


# In[100]:


GHP=nx.Graph()
for i,e in enumerate(Gn_All.edges()):
    if Gn_All[e[0]][e[1]]['weight']>0.1:
        GHP.add_edge(e[0],e[1])
print(len(GHP.edges()))


# In[101]:


G1=nx.Graph()
for i,e in enumerate(GHP.edges()):
    if (e[0] in set_lst and e[1] not in Pid_H) or (e[1] in set_lst and e[0] not in Pid_H):
        G1.add_edge(e[0],e[1])
print(len(G1.edges()))


# In[110]:


Hst=[];Pth=[]
for e in G1.edges():
    if e[0] in set_lst:
        Hst.append(e[0])
    else:
        Pth.append(e[0])
    if e[1] in set_lst:
        Hst.append(e[1])
    else:
        Pth.append(e[1])
Hst=list(set(Hst))    
Pth=list(set(Pth))
print(len(Hst))
print(len(Pth))


# In[111]:


s=''
for n in Hst:
    s+='{}\n'.format(n)
f=open("./Total_Covid_Virus/Humans.txt","w")
f.write(s);f.close()    


# In[105]:


s=''
for e in G1.edges():
    s+='{}\t{}\n'.format(e[0],e[1])
f=open("./Total_Covid_Virus/Vulnerable Host Interactions.csv","w")
f.write(s);f.close()


# In[ ]:


with open('./Total_Covid_Virus/Vulnerable Host Interactions.csv', 'w') as csvfile: 
    # creating a csv writer object 
    csvwriter = csv.writer(csvfile) 


# In[25]:


hm0_lst=[];hm1_lst=[];hm2_lst=[];hm3_lst=[];hm4_lst=[];hm5_lst=[];hm6_lst=[];hm7_lst=[];hm8_lst=[];hm9_lst=[];hm10_lst=[]
hm0_lst=list(hm0)
hm1_lst=list(hm1)
hm2_lst=list(hm2)
hm3_lst=list(hm3)
hm4_lst=list(hm4)
hm5_lst=list(hm5)
hm6_lst=list(hm6)
hm7_lst=list(hm7)
hm8_lst=list(hm8)
hm9_lst=list(hm9)
hm10_lst=list(hm10)


# In[37]:


hmm0_lst=[];hmm1_lst=[];hmm2_lst=[]
hmm0_lst=list(hmm0)
hmm1_lst=list(hmm1)
hmm2_lst=list(hmm2)


# In[40]:


s=''
for ls in hmm2_lst:
    s+="{}\n".format(ls)
f=open("./Total_Covid_Virus/Individual Protein List/TH_0.001/Bov_Mur_Rat_CoV.txt","w")
f.write(s);f.close()


# In[38]:


import matplotlib.pyplot as plt
from matplotlib_venn import venn3


# In[26]:


s=''
for ls in set_lst:
    s+="{}\n".format(ls)
f=open("./Total_Covid_Virus/Intersected_Host_Protein_0.1.txt","w")
f.write(s);f.close()

